window.addEventListener('load',canvasApp);
//宽500长500
function canvasApp() {
    var c=document.getElementById("myCanvas");
    var ctx=c.getContext("2d");
    ctx.beginPath();
    // ctx.lineWidth=10;
    ctx.lineJoin="round";
    newRoot(500,700,160,Math.PI/2, 0,28);
    function newRoot (x,y,l,o, cnt,lineWidth) {
        if (cnt > 12) return;
        var p = Math.random()*2;
        ctx.lineWidth = lineWidth;
        ctx.moveTo(x,y);//根节点
        ctx.lineTo(x+Math.cos(o)*l,y-Math.sin(o)*l);//树干
        newRoot(x+Math.cos(o)*l, y-Math.sin(o)*l,4*(l/parseInt(p*2+5)), o+Math.PI/parseInt(p*4+8), cnt + 1,ctx.lineWidth-2);
        newRoot(x+Math.cos(o)*l, y-Math.sin(o)*l,4*(l/parseInt(p*2+5)), o-Math.PI/parseInt(p*4+8), cnt + 1,ctx.lineWidth-2);
    }

    ctx.stroke();
}
canvasApp();
